const express = require("express");
require("../src/db/conn");
const router = require("./routers/men")
const MensRanking =require("../src/models/mens");
const app = express();
const port =8000;

// app.get ("/",async(req,res)=>{
//     res.send("hello from the parth")
// })
app.use(express.json());
app.use(router);


app.listen(port,()=>{
    console.log(`example app listening at http://localhost:${port}`)
  })

  
