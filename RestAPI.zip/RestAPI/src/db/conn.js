const mongoose = require("mongoose");
// mongoose.connect("mongodb://0.0.0.0:27017/userlogin",{
//     useCreateIndex:true,
//     useNewUrlParser: true,
//     useUnifiedTopology: true,
// }).then(()=>{
//     console.log("connection successful");
// }).catch((e) =>{
//     console.log(e);
// })

mongoose.connect("mongodb://0.0.0.0:27017/userlogin", {
    //useCreateIndex:true,  
    useNewUrlParser: true,
    useUnifiedTopology: true,
}).then(()=>{
  console.log("connectd")
}).catch((e)=>{
  console.log(e);
})
