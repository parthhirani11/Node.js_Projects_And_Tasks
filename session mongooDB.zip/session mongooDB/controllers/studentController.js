class StudentController{

    static session_example = (req,res)=>{
        req.session.device = "mobile"
        if(req.session.count){
            req.session.count++
        }else{
            req.session.count =1
        }
        res.send(`count: ${req.session.count}`)
    }

    static get_session_data = (req,res)=>{
        if(req.session.device){
            res.send(`Device:${req.session.device} Count: ${req.session.count}`)
        }else{
            res.send("session date device not found")
        }
    }
}

export default StudentController