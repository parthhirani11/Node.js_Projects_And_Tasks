const mongoose = require('mongoose');
require('dotenv').config()
mongoose.set('strictQuery', false);

const connectDB = async()=> {
 
  try {
   
    const conn = await mongoose.connect(process.env.DATABASE_URL);
    console.log(`Database Connected: ${conn.connection.host}`);
  } catch (error) {
    console.log(error);
  }
}
module.exports = connectDB;