class StudentController{
    static get_session_info= (req,res)=>{
       console.log(req.session)
       console.log(req.session.id)
       console.log(req.session.cookie)
       console.log(req.session.cookie.maxAge)
       console.log(req.session.cookie.originalMaxAge)
       console.log(req.session.sessionID)
        res.send("session info...")
    } 

    static regn_session = (req,res)=>{
        res.session.regenerate(()=>{
            console.log(`Session regenerate... session ${req.sesstion.id}`)
        })
        res.send("session regenerate")
    }

    static delete_session = (req,res)=>{
        res.session.destroy(()=>{
            console.log(`Session deleted... session ${req.sesstion.id}`)
        })
        res.send("session deleted")
    
    }

    static session_example = (req,res)=>{
        req.session.device = "mobile"
        if(req.session.count){
            req.session.count++
        }else{
            req.session.count =1
        }
        res.send(`count: ${req.session.count}`)
    }

    static get_session_data = (req,res)=>{
        if(req.session.device){
            res.send(`Device:${req.session.device} Count: ${req.session.count}`)
        }else{
            res.send("session date device not found")
        }
    }
}

export default StudentController