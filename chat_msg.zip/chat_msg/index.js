const express = require('express');

const app = express();
const http= require("http").createServer(app);
const io = require('socket.io')(http,{cors:{origin:"*"}})
 
app.set('views', __dirname + '/views');
app.set('view engine','ejs'); 

app.get('/',(req,res)=>{
    res.render('home')
})



io.on("connection",(socket)=>{
    console.log("user" + socket.id);

    socket.on("message",(data)=>{
        socket.emit('message',data)
    })
    
});


http.listen(8000,()=>{
    console.log("server running in 8000");
});