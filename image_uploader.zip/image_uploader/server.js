const express = require('express')
const app = express();
//const hbs = require('express-handlebars');
const path = require('path');
const hbs = require("hbs")
const connectDB = require('./server/database/database');
app.use(express.json());

app.use(express.static(path.join(__dirname,'public')))

connectDB();


const pars =path.join(__dirname, "views/partials");

app.use(express.static(path.join(__dirname,"views")));
app.set("view engine","hbs");

hbs.registerPartials(pars);



app.use('/', require('./server/router/router'))

app.listen(3000,()=>console.log(`server is started on http://localhost:3000`));