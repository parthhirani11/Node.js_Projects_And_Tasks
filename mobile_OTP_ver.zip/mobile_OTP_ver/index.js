require('dotenv').config()
const OTP = require("./mongo")
const express = require('express');
const ejs = require('ejs');
const app = express();
//const mongoose = require('mongoose');


const accountSid = process.env.TWILIO_ACCOUNT_SID;
const authToken = process.env.TWILIO_AUTH_TOKEN;
const client = require('twilio')(accountSid, authToken);




app.use(express.urlencoded({extended:true}));
app.use(express.json());

app.set("view engine" , "ejs");
app.use(express.static("public"));


app.post("/error" ,function(req,res){
    res.render("verify")
})
app.get("/",function(req,res){
    res.render("home")
})

app.get("/verify",function(req,res){
    res.render("verify")
})

app.post("/verify",function(req,res){
    const code = req.body.code

        console.log(code)
        OTP.findOne({users:code}).then((err)=>{
            if(err != null){
                res.render("success")
                // OTP.findByIdAndDelete(code).then((er)=>{
                //     if(er){
                //         console.log(er)
                //     }else{
                //         console.log("delete OTP");
                //     }
                // })
                            
            }else{
                res.render("error")
            }
        })
    })   

   

app.post("/ver" ,function(req,res){
    const number = req.body.number

    let randomN = Math.floor(Math.random() * 9000)+10000;

    client.messages
      .create({body: randomN, from: '+12524659256', to: '+91'+ number})
      .then(saveUser());

      function saveUser(){
        const newUser = new OTP({
            users: randomN
            
            
        })
        newUser.save().then((e)=>{
            if(e != null){
                console.log(e)
                res.render("verify")
            }
        })
      }
})


let port = process.env.PORT;
if(port == null || port == ""){
    port = 8081;
}

app.listen(port,function(){
    console.log(`app started successfully ${port}`)
})