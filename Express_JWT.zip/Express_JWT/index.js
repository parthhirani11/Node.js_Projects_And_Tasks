const express = require('express');
const jwt = require('jsonwebtoken');
const app = express();
const secretkey= "sekretkey";
app.get("/",(req,res)=>{
    res.json({
        message:"hello parth"
    })
})

app.post("/login",(req,res)=>{

    const user={
        id:1,
        username:"parth",
        email:"parth@gmail.com"
    }
    jwt.sign({user},secretkey,{expiresIn:'300s'},(err,token)=>{
        res.json({
            token
        })
    })
})

app.post("/profile",verifyToken,(req,res)=>{
    jwt.verify(req.token,secretkey,(err,authDath)=>{
        if(err){
        res.send({
            result:"invalid token"

        })
    }else{
        res.json({
        message:"profile accessed",
        authDath
    })
    }
    })
})

function verifyToken(req,res,next){
    const bearerHeader = req.headers['authorization'];
    if(bearerHeader !== 'undefined'){
       const bearer = bearerHeader.split(" ");
       const token = bearer[1];
       req.token = token;
       next();
    }else{
         res.send({
            result:"token is not valid"
        })
    }
}

const port = 5051;
app.listen(port,()=>{
    console.log(`app is running is ${port}`)
})