const mongoose = require('mongoose');
require('dotenv').config()
mongoose.set('strictQuery', false);

const connectDB = async()=> {
  console.log(process.env.MONGO_URI);
  try {
   
    const conn = await mongoose.connect(process.env.MONGO_URI);
    console.log(`Database Connected: ${conn.connection.host}`);
  } catch (error) {
    console.log(error);
  }
}
module.exports = connectDB;