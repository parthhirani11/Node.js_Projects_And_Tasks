const express = require("express");
const app = express();
const path = require('path');
const hbs = require("hbs");
const { request } = require("http");
//const requests = require("requests");

const Static =path.join(__dirname, "../public");
app.use(express.static(Static));

const pars =path.join(__dirname, "../tem/pars");
//app.set('views', __dirname + '../tem/views');
app.use(express.static(path.join(__dirname,"../tem/views")));
app.set("view engine","hbs");

hbs.registerPartials(pars);


app.get("/",(req,res)=>{
    res.render("index")
});

// app.get("/about",(req,res)=>{
//     console.log("parth");
//     requests(
//         `http://api.openweathermap.org/data/2.5/weather?q=${req.query.name}&units=metric&appid=`
//       )
//         .on("data", (chunk) => {
//           const objdata = JSON.parse(chunk);
//           const arrData = [objdata];
//            console.log(`city name is ${arrData[0].name}and the temp is ${arrData[0].name.temp}`);
          
//           res.write(arrData[0].name);
//           // console.log(realTimeData);
//         })
//         .on("end", (err) => {
//           if (err) return console.log("connection closed due to errors", err);
//           res.end();
//         });
//     });

// app.get("*",(req,res)=>{
//     res.render("../tem/views/404",{
//         errorcomemnt:"opps page couldn't  be found",
//     })
// });

  var server = app.listen(8081, function () {
    var host = server.address().address
    var port = server.address().port
    
    console.log("Example app listening at http://%s:%s", host, port)
 })