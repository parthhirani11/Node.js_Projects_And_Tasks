import express from 'express'
import web from './routes/web.js'
import session, { Store } from 'express-session'
import connectDB  from './db/connectdb.js';
import MongoStore from 'connect-mongo';
const app = express()
const port =process.env.PORT || '3000'
const DATABASE_URL = process.env.DATABASE_URL || "mongodb://0.0.0.0:27017"

connectDB(DATABASE_URL);
const sessionStorage = MongoStore.create({
    mongoUrl:DATABASE_URL,
    dbname:'datasession',
    collection:'sessions',
    ttl:14*24*60*60,
    autoRemove:'native'
})

app.use(session({
    name:'parthsession',
    secret:'iamkey',
    resave:false,
    saveUninitialized:true,
    cookie:{maxAge:100000},
    Store:sessionStorage

}))
//app.use(cookieParser())
app.use('/',web)

app.listen(port,()=>{
    console.log(`server listening at http://localhost:${port}`)
})