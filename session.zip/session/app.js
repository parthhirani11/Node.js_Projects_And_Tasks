import express from 'express'
import cookieParser from 'cookie-parser'
import web from './routes/web.js'
import session from 'express-session'
const app = express()
const port =process.env.PORT || '3000'


app.use(session({
    name:'parthsession',
    secret:'iamkey',
    resave:false,
    saveUninitialized:true,
    cookie:{maxAge:200000}

}))
//app.use(cookieParser())
app.use('/',web)

app.listen(port,()=>{
    console.log(`server listening at http://localhost:${port}`)
})