const mongoose = require('mongoose');
mongoose.set('strictQuery', false);

const connectDB = async()=> {
  mongoose.connect("mongodb://0.0.0.0:27017/LoginFormPractice", {
    useNewUrlParser: true,
    useUnifiedTopology: true,
}).then(()=>{
    console.log("mongoosesss connected");
}).catch((e)=>{
    console.log(e);
})


  // try {
   
  //   const conn = await mongoose.connect(process.env.MONGODB_URI);
  //   console.log(`Database Connected: ${conn.connection.host}`);
  // } catch (error) {
  //   console.log(error);
  // }
}

module.exports = connectDB;
//......................................................

//const mongoose=require("mongoose")

