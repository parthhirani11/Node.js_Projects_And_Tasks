var express = require("express");
const router = express.Router();
const Student = require("../models/Students");

// router.get("/login", (req, res) => {
//   res.render("student/login");
// });
// router.post("/login", async (req, res) => {

//     const Stuname = req.body.name;
//     const individualStudent = await Student.findOne({name : Stuname});
//     if(!individualStudent){
//       res.render("student/login", {
//         error : "Login with correct user name"
//       })
//     }
//     res.render("student/view", { one : individualStudent})
// });


router.get("/login", (req, res) => {
  res.render("student/login");
});
router.post("/login", async (req, res) => {

  if(req.body.password == "admin"){
    res.redirect("student/view");
  }
  else{
    res.render("student/login", {
        error : "Please Enter Correct Password !!"
    })
  }
    const individualStudent = await Student.find({});
    
    res.render("student/view", { one : individualStudent})
});

router.get("/mens",async(req,res)=>{
  try{
      const _id = req.params.id;
      const getMean = await MensRanking.find({});
      // .sort({"ranking":1})
  
       res.send(getMean);
  }catch(e){
      res.status(400).send(e);

  }
})


module.exports = router;
