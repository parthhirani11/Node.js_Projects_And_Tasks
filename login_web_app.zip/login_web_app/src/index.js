const express = require("express")
const path = require("path")
const app = express()
 const hbs = require("hbs")
const LogInCollection = require("./mongo")
const LogInCollectiona = require("./mongoo")
//const connectDB = require('./mongo');
//connectDB();

const port = process.env.PORT || 5000
app.use(express.json())

app.use(express.urlencoded({ extended: false }))

const ProfilePath = path.join(__dirname, '../tempelates')
const publicPath = path.join(__dirname, '../public')
console.log(publicPath);

app.set('view engine', 'hbs')
app.set('views', ProfilePath)
app.use(express.static(publicPath))


// hbs.registerPartials(partialPath)


app.get('/signup', (req, res) => {
    res.render('signup')
})
app.get('/login', (req, res) => {
    res.render('login')
})

app.get('/', (req, res) => {
    res.render('index')
})


app.get('/home', (req, res) => {
    res.render('home')
})

app.post('/in', async (req, res) => {
    res.render("login");
})
app.post('/logout', async (req, res) => {
    res.render("index");
})

app.post('/dex', async (req, res) => {
    res.render("signup");
})

app.post('/signup', async (req, res) => {
   
    console.log(req.body.name,req.body.password)

    const data = {
        name: req.body.name,
        password: req.body.password,
        email:req.body.email,
        city:req.body.city

    }

    const checking = await LogInCollection.findOne({ name: req.body.email }).count()

    console.log(checking)

   try{
    if (checking !=0) {
        res.send("user details already exists")
    }
    else{
        await LogInCollection.insertMany([data])
        res.status(201).render("login", {
            naming: req.body.email
        })
    }
   }
   catch (e){
    console.log(e);
    res.send("wrong inputs")
   }

   
})


app.post('/login', async (req, res) => {

    try {
        const check = await LogInCollection.findOne({ email: req.body.email })

        if (check.password === req.body.password) {
            res.status(201).render("home", { naming: `${req.body.email}` })
        }

        else {
            res.send("incorrect password")
        }


    } 
    
    catch (e) {

        res.send("wrong details")
        

    }


})

app.post('/msg', async (req, res) => {
    
    console.log(req.body.nname,req.body.email,req.body.message)

    const dataa = {
        nname: req.body.nname,
        email:req.body.email,
        message: req.body.message
    }

    //console.log(data)

    const checkingg = await LogInCollectiona.findOne({ nname: req.body.nname }).count()

    
   try{
        await LogInCollectiona.insertMany([dataa])
        console.log(checkingg)

        res.status(201).render("home", {
            naming: req.body.naame
        })
   }
   catch (e){
    console.log(e);
    res.send("wrong inputs")
   }


   
})

app.listen(port, () => {
    console.log('port connected 5000');
})