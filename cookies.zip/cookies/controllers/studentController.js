class StudentController{
    static set_cookie = (req,res)=>{
        res.cookie("username","parthhirani")
        res.cookie("cart",5)
        //res.cookie("username","parthhirani",{maxage:30000})
        res.send("cookie set...")
    } 

    static get_cookie = (req,res)=>{
         console.log(req.cookie)
         console.log(req.cookies.username.cart)
         console.log(req.cookies)
        res.send("cookie get...")
    }

    static delete_cookie = (req,res)=>{
        res.clearCookie("username")
        res.send("cookie delete...")
    }
}

export default StudentController