const config = {
    MONGO_URI: "mongodb+srv://parthhirani:HCptOJJwEmRwYGfX@uploader.iyz0gld.mongodb.net/"
}

module.exports = config;
