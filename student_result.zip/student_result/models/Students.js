const mongoose = require("mongoose")
const { Schema } = mongoose;

const studentSchema = new Schema({
  name:  {
    type : String,
    unique : true
  },
  roll: Number,
  py:   String,
  ds: String,
  aj: String,
  paj: String,
  pds: String,
  status : String
});
module.exports = mongoose.model("Student", studentSchema)