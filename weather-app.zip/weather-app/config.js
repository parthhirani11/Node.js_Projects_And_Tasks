const constants = {
    openWeatherMap: {
        BASE_URL: "https://api.openweathermap.org/data/2.5/weather?q=",
        SECRET_KEY: "3709f89e826c2838310e77a773533f2d"
        //PRztE1cowqdzqehxKI502phMbS5pEtnA"
        //253c1b73b3b4da02744bb282f0db4664"
        //3709f89e826c2838310e77a773533f2d
    }
}
module.exports = constants;

