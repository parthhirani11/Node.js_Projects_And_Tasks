const mongoose=require("mongoose")

mongoose.connect("mongodb://0.0.0.0:27017/LoginFormPractice", {
    useNewUrlParser: true,
    useUnifiedTopology: true,
}).then(()=>{
    console.log("mongoosesss connected");
}).catch((e)=>{
    console.log(e);
})

const logInSchemaa=new mongoose.Schema({
    nname:{
        type:String,
        required:true
    },
    email:{
        type:String,
        required:true
    },
    message:{
        type:String,
        required:true
    },
    
})

const LogInCollectiona=new mongoose.model('msg',logInSchemaa)

module.exports=LogInCollectiona



