
    blogs= [
        {
            title:"move",
            content:"this is content move",
            slug:"move-learn"

        },
        {
            title:"java",
            content:"this is content java",
            slug:"java-learn"
        },
        {
            title:"PHP",
            content:"this is content PHP",
            slug:"PHP-learn"
        },
        {
            title:"Node",
            content:"this is content Node",
            slug:"Node-learn"
        },
    ]


module.exports = blogs;